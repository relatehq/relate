# Relate SDK eval: oracle-final

Reference-solution validation; not a model benchmark.

| Agent | Slice | Pass / planned | Scored | Errors | Missing | Input / output tokens |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| oracle | all | 84 / 84 | 84 | 0 | 0 | 0 / 0 |
| oracle | family:atomic-failure | 3 / 3 | 3 | 0 | 0 | 0 / 0 |
| oracle | family:bulk-reviews | 3 / 3 | 3 | 0 | 0 | 0 / 0 |
| oracle | family:business-failure | 3 / 3 | 3 | 0 | 0 | 0 / 0 |
| oracle | family:count-all-tickets | 3 / 3 | 3 | 0 | 0 | 0 / 0 |
| oracle | family:create-review | 3 / 3 | 3 | 0 | 0 | 0 / 0 |
| oracle | family:cross-domain-workflow | 3 / 3 | 3 | 0 | 0 | 0 / 0 |
| oracle | family:cursor-page | 3 / 3 | 3 | 0 | 0 | 0 / 0 |
| oracle | family:deduplicate-join | 3 / 3 | 3 | 0 | 0 | 0 / 0 |
| oracle | family:discover-objects | 3 / 3 | 3 | 0 | 0 | 0 / 0 |
| oracle | family:empty-result | 3 / 3 | 3 | 0 | 0 | 0 / 0 |
| oracle | family:filter-reference | 3 / 3 | 3 | 0 | 0 | 0 / 0 |
| oracle | family:filter-status | 3 / 3 | 3 | 0 | 0 | 0 / 0 |
| oracle | family:idempotent-retry | 3 / 3 | 3 | 0 | 0 | 0 / 0 |
| oracle | family:lookup-account | 3 / 3 | 3 | 0 | 0 | 0 / 0 |
| oracle | family:numeric-range | 3 / 3 | 3 | 0 | 0 | 0 / 0 |
| oracle | family:rank-accounts | 3 / 3 | 3 | 0 | 0 | 0 / 0 |
| oracle | family:receipt-lookup | 3 / 3 | 3 | 0 | 0 | 0 / 0 |
| oracle | family:recover-read-error | 3 / 3 | 3 | 0 | 0 | 0 / 0 |
| oracle | family:restricted-field | 3 / 3 | 3 | 0 | 0 | 0 / 0 |
| oracle | family:retry-conflict | 3 / 3 | 3 | 0 | 0 | 0 / 0 |
| oracle | family:row-scope | 3 / 3 | 3 | 0 | 0 | 0 / 0 |
| oracle | family:select-fields | 3 / 3 | 3 | 0 | 0 | 0 / 0 |
| oracle | family:sum-invoices | 3 / 3 | 3 | 0 | 0 | 0 / 0 |
| oracle | family:timestamp-range | 3 / 3 | 3 | 0 | 0 | 0 / 0 |
| oracle | family:traverse-many | 3 / 3 | 3 | 0 | 0 | 0 / 0 |
| oracle | family:traverse-one | 3 / 3 | 3 | 0 | 0 | 0 / 0 |
| oracle | family:traverse-through | 3 / 3 | 3 | 0 | 0 | 0 / 0 |
| oracle | family:untrusted-subject | 3 / 3 | 3 | 0 | 0 | 0 / 0 |
| oracle | level:1 | 18 / 18 | 18 | 0 | 0 | 0 / 0 |
| oracle | level:2 | 21 / 21 | 21 | 0 | 0 | 0 / 0 |
| oracle | level:3 | 21 / 21 | 21 | 0 | 0 | 0 / 0 |
| oracle | level:4 | 24 / 24 | 24 | 0 | 0 | 0 / 0 |

`report.json` retains per-task results, errors, limits, SDK failures, latency and pass@k / pass^k. Reliability requires k repeated trials of the same task; data variants are not repeats. Missing/error trials stay in the planned denominator. Token usage includes retained incomplete samples; it is not a dollar bill.

Browse full model/tool transcripts with `uv run inspect view --recursive --log-dir <run>/logs`. Expected answers, state comparisons and SDK calls are retained in each Inspect log.
