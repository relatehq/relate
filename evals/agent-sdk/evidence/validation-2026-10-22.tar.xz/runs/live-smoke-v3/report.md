# Relate SDK eval: live-smoke-v3

Agent means model plus solver, prompt, tools and budgets. These results measure this suite only.

| Agent | Slice | Pass / planned | Scored | Errors | Missing | Input / output tokens |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| haiku | all | 8 / 16 | 9 | 7 | 0 | 289999 / 11456 |
| haiku | family:count-all-tickets | 2 / 2 | 2 | 0 | 0 | 49299 / 2681 |
| haiku | family:create-review | 1 / 2 | 1 | 1 | 0 | 30743 / 743 |
| haiku | family:cross-domain-workflow | 0 / 2 | 1 | 1 | 0 | 60463 / 2225 |
| haiku | family:cursor-page | 1 / 2 | 1 | 1 | 0 | 11584 / 514 |
| haiku | family:idempotent-retry | 1 / 2 | 1 | 1 | 0 | 42343 / 1157 |
| haiku | family:recover-read-error | 1 / 2 | 1 | 1 | 0 | 38642 / 1872 |
| haiku | family:restricted-field | 1 / 2 | 1 | 1 | 0 | 22915 / 1184 |
| haiku | family:traverse-through | 1 / 2 | 1 | 1 | 0 | 34010 / 1080 |
| haiku | level:1 | 2 / 2 | 2 | 0 | 0 | 49299 / 2681 |
| haiku | level:2 | 2 / 4 | 2 | 2 | 0 | 45594 / 1594 |
| haiku | level:3 | 2 / 4 | 2 | 2 | 0 | 61557 / 3056 |
| haiku | level:4 | 2 / 6 | 3 | 3 | 0 | 133549 / 4125 |
| nano | all | 1 / 16 | 16 | 0 | 0 | 432017 / 11057 |
| nano | family:count-all-tickets | 1 / 2 | 2 | 0 | 0 | 37776 / 934 |
| nano | family:create-review | 0 / 2 | 2 | 0 | 0 | 36096 / 1059 |
| nano | family:cross-domain-workflow | 0 / 2 | 2 | 0 | 0 | 116794 / 2328 |
| nano | family:cursor-page | 0 / 2 | 2 | 0 | 0 | 15978 / 530 |
| nano | family:idempotent-retry | 0 / 2 | 2 | 0 | 0 | 78134 / 2087 |
| nano | family:recover-read-error | 0 / 2 | 2 | 0 | 0 | 17213 / 1034 |
| nano | family:restricted-field | 0 / 2 | 2 | 0 | 0 | 42099 / 1500 |
| nano | family:traverse-through | 0 / 2 | 2 | 0 | 0 | 87927 / 1585 |
| nano | level:1 | 1 / 2 | 2 | 0 | 0 | 37776 / 934 |
| nano | level:2 | 0 / 4 | 4 | 0 | 0 | 103905 / 2115 |
| nano | level:3 | 0 / 4 | 4 | 0 | 0 | 59312 / 2534 |
| nano | level:4 | 0 / 6 | 6 | 0 | 0 | 231024 / 5474 |

`report.json` retains per-task results, errors, limits, SDK failures, latency and pass@k / pass^k. Reliability requires k repeated trials of the same task; data variants are not repeats. Missing/error trials stay in the planned denominator. Token usage includes retained incomplete samples; it is not a dollar bill.

Browse full model/tool transcripts with `uv run inspect view --recursive --log-dir <run>/logs`. Expected answers, state comparisons and SDK calls are retained in each Inspect log.
