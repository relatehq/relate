# Relate SDK eval: live-smoke-final

Agent means model plus solver, prompt, tools and budgets. These results measure this suite only.

| Agent | Slice | Pass / planned | Scored | Errors | Missing | Input / output tokens |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| haiku | all | 11 / 16 | 16 | 0 | 0 | 609934 / 20092 |
| haiku | family:count-all-tickets | 2 / 2 | 2 | 0 | 0 | 39975 / 2059 |
| haiku | family:create-review | 1 / 2 | 2 | 0 | 0 | 101478 / 2322 |
| haiku | family:cross-domain-workflow | 0 / 2 | 2 | 0 | 0 | 136819 / 4740 |
| haiku | family:cursor-page | 2 / 2 | 2 | 0 | 0 | 21318 / 834 |
| haiku | family:idempotent-retry | 1 / 2 | 2 | 0 | 0 | 109679 / 2619 |
| haiku | family:recover-read-error | 2 / 2 | 2 | 0 | 0 | 51001 / 2124 |
| haiku | family:restricted-field | 1 / 2 | 2 | 0 | 0 | 95785 / 3674 |
| haiku | family:traverse-through | 2 / 2 | 2 | 0 | 0 | 53879 / 1720 |
| haiku | level:1 | 2 / 2 | 2 | 0 | 0 | 39975 / 2059 |
| haiku | level:2 | 4 / 4 | 4 | 0 | 0 | 75197 / 2554 |
| haiku | level:3 | 3 / 4 | 4 | 0 | 0 | 146786 / 5798 |
| haiku | level:4 | 2 / 6 | 6 | 0 | 0 | 347976 / 9681 |
| nano | all | 0 / 16 | 16 | 0 | 0 | 495573 / 13649 |
| nano | family:count-all-tickets | 0 / 2 | 2 | 0 | 0 | 69083 / 1488 |
| nano | family:create-review | 0 / 2 | 2 | 0 | 0 | 74797 / 2449 |
| nano | family:cross-domain-workflow | 0 / 2 | 2 | 0 | 0 | 66414 / 1992 |
| nano | family:cursor-page | 0 / 2 | 2 | 0 | 0 | 22341 / 1004 |
| nano | family:idempotent-retry | 0 / 2 | 2 | 0 | 0 | 98985 / 2482 |
| nano | family:recover-read-error | 0 / 2 | 2 | 0 | 0 | 10165 / 991 |
| nano | family:restricted-field | 0 / 2 | 2 | 0 | 0 | 53437 / 1229 |
| nano | family:traverse-through | 0 / 2 | 2 | 0 | 0 | 100351 / 2014 |
| nano | level:1 | 0 / 2 | 2 | 0 | 0 | 69083 / 1488 |
| nano | level:2 | 0 / 4 | 4 | 0 | 0 | 122692 / 3018 |
| nano | level:3 | 0 / 4 | 4 | 0 | 0 | 63602 / 2220 |
| nano | level:4 | 0 / 6 | 6 | 0 | 0 | 240196 / 6923 |

`report.json` retains per-task results, errors, limits, SDK failures, latency and pass@k / pass^k. Reliability requires k repeated trials of the same task; data variants are not repeats. Missing/error trials stay in the planned denominator. Token usage includes retained incomplete samples; it is not a dollar bill.

Browse full model/tool transcripts with `uv run inspect view --recursive --log-dir <run>/logs`. Expected answers, state comparisons and SDK calls are retained in each Inspect log.
