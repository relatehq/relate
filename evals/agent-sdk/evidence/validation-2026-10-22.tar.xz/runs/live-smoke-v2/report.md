# Relate SDK eval: live-smoke-v2

Agent means model plus solver, prompt, tools and budgets. These results measure this suite only.

| Agent | Slice | Pass / planned | Scored | Errors | Missing | Input / output tokens |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| haiku | all | 0 / 16 | 0 | 0 | 16 | 0 / 0 |
| haiku | family:count-all-tickets | 0 / 2 | 0 | 0 | 2 | 0 / 0 |
| haiku | family:create-review | 0 / 2 | 0 | 0 | 2 | 0 / 0 |
| haiku | family:cross-domain-workflow | 0 / 2 | 0 | 0 | 2 | 0 / 0 |
| haiku | family:cursor-page | 0 / 2 | 0 | 0 | 2 | 0 / 0 |
| haiku | family:idempotent-retry | 0 / 2 | 0 | 0 | 2 | 0 / 0 |
| haiku | family:recover-read-error | 0 / 2 | 0 | 0 | 2 | 0 / 0 |
| haiku | family:restricted-field | 0 / 2 | 0 | 0 | 2 | 0 / 0 |
| haiku | family:traverse-through | 0 / 2 | 0 | 0 | 2 | 0 / 0 |
| haiku | level:1 | 0 / 2 | 0 | 0 | 2 | 0 / 0 |
| haiku | level:2 | 0 / 4 | 0 | 0 | 4 | 0 / 0 |
| haiku | level:3 | 0 / 4 | 0 | 0 | 4 | 0 / 0 |
| haiku | level:4 | 0 / 6 | 0 | 0 | 6 | 0 / 0 |
| nano | all | 1 / 16 | 16 | 0 | 0 | 450313 / 12741 |
| nano | family:count-all-tickets | 1 / 2 | 2 | 0 | 0 | 31163 / 1522 |
| nano | family:create-review | 0 / 2 | 2 | 0 | 0 | 70062 / 1548 |
| nano | family:cross-domain-workflow | 0 / 2 | 2 | 0 | 0 | 126165 / 2805 |
| nano | family:cursor-page | 0 / 2 | 2 | 0 | 0 | 9256 / 620 |
| nano | family:idempotent-retry | 0 / 2 | 2 | 0 | 0 | 70729 / 1720 |
| nano | family:recover-read-error | 0 / 2 | 2 | 0 | 0 | 13458 / 1428 |
| nano | family:restricted-field | 0 / 2 | 2 | 0 | 0 | 33983 / 1237 |
| nano | family:traverse-through | 0 / 2 | 2 | 0 | 0 | 95497 / 1861 |
| nano | level:1 | 1 / 2 | 2 | 0 | 0 | 31163 / 1522 |
| nano | level:2 | 0 / 4 | 4 | 0 | 0 | 104753 / 2481 |
| nano | level:3 | 0 / 4 | 4 | 0 | 0 | 47441 / 2665 |
| nano | level:4 | 0 / 6 | 6 | 0 | 0 | 266956 / 6073 |

`report.json` retains per-task results, errors, limits, SDK failures, latency and pass@k / pass^k. Reliability requires k repeated trials of the same task; data variants are not repeats. Missing/error trials stay in the planned denominator. Token usage includes retained incomplete samples; it is not a dollar bill.

Browse full model/tool transcripts with `uv run inspect view --recursive --log-dir <run>/logs`. Expected answers, state comparisons and SDK calls are retained in each Inspect log.
